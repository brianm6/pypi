__title__ = "djangorestframework-jsonapi"
__version__ = "5.0.0"
__author__ = ""
__license__ = "BSD"
__copyright__ = ""

# Version synonym
VERSION = __version__
