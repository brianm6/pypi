==========================================
 ``celery.bin.worker``
==========================================

.. contents::
    :local:
.. currentmodule:: celery.bin.worker

.. automodule:: celery.bin.worker
    :members:
    :undoc-members:
