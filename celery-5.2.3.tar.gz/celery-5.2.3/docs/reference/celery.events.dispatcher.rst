=================================================================
 ``celery.events.state``
=================================================================

.. contents::
    :local:
.. currentmodule:: celery.events.dispatcher

.. automodule:: celery.events.dispatcher
    :members:
    :undoc-members:
