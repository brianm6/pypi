=======================================
 ``celery.apps.worker``
=======================================

.. contents::
    :local:
.. currentmodule:: celery.apps.worker

.. automodule:: celery.apps.worker
    :members:
    :undoc-members:
