===========================================
 ``celery.utils.abstract``
===========================================

.. contents::
    :local:
.. currentmodule:: celery.utils.abstract

.. automodule:: celery.utils.abstract
    :members:
    :undoc-members:
