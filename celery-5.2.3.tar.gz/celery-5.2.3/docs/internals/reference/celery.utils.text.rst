=====================================================
 ``celery.utils.text``
=====================================================

.. contents::
    :local:
.. currentmodule:: celery.utils.text

.. automodule:: celery.utils.text
    :members:
    :undoc-members:
